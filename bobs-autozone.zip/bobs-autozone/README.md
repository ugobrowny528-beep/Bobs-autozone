# Bob's Autozone

A PHP + MySQL auto-parts platform. Visitors browse a live parts catalog, fill out an order form that is **saved into a MySQL database**, and track the order with a reference code. Built from the textbook's include/header/footer pattern and extended with a database layer.

## Requirements
- PHP 8.0 or newer
- MySQL or MariaDB (the "web database for PHP")
- Easiest local setup: [XAMPP](https://www.apachefriends.org) (includes PHP, MySQL, and phpMyAdmin)

## Setup
1. **Copy the project** into your web folder. With XAMPP: `C:\xampp\htdocs\bobs-autozone` (Mac: `/Applications/XAMPP/htdocs/`).
2. **Start** Apache and MySQL in the XAMPP control panel.
3. **Create the database**: open `http://localhost/phpmyadmin`, click **Import**, choose `database/schema.sql`, and click **Go**. This creates the `bobs_autozone` database, both tables, and 12 sample parts.
4. **Add your credentials**: copy `config.sample.php` to `config.php` and edit it. XAMPP defaults (user `root`, empty password) work as-is.
5. **Open** `http://localhost/bobs-autozone/`.

Without XAMPP you can run `php -S localhost:8000` in the project folder, as long as PHP has the `pdo_mysql` extension and MySQL is running.

### Hosting it online
Any PHP host with MySQL works. Create a database and user in the host's control panel, import `schema.sql` (remove the first `CREATE DATABASE` / `USE` lines if the host gives you a fixed database name), then put those details in `config.php` on the server.

## Pages
| File | Purpose |
|---|---|
| `index.php` | Home page; shows random in-stock parts and a live count from the database |
| `parts.php` | Catalog read from the `parts` table, with category filter and stock badges |
| `order.php` | **The form** that saves data into the database |
| `status.php` | Order confirmation and order tracker (reads data back from the database) |
| `includes/header.php`, `footer.php` | Shared layout, included on every page |
| `includes/db.php` | Secure PDO database connection |
| `includes/functions.php` | Escaping, CSRF protection, `save_request()`, `find_request()` |
| `database/schema.sql` | Tables and sample data |
| `config.sample.php` | Template for your private `config.php` |

## How the form talks to the database
1. `order.php` loads the in-stock parts from the `parts` table to fill the part dropdown.
2. On submit, the page checks the CSRF token, trims every field and validates it (email format, year range, quantity 1-10, address required for delivery, length limits, and that the chosen part is a real in-stock part).
3. `save_request()` opens a **transaction**: it locks the part row, checks stock, reads the **price from the database** (never from the browser), inserts one row into `part_requests` with a prepared statement, and subtracts the quantity from `parts.stock`. If anything fails, everything is rolled back.
4. The visitor is redirected to `status.php`, which reads the saved row back with a `JOIN` and shows the receipt.

### Fields saved in `part_requests`
Reference code, name, email, phone, vehicle year/make/model, part, quantity, unit price, total price, pickup or delivery, delivery address, notes, status, and created time.

## Security features
- **Prepared statements** (PDO, emulation off) on every query: protects against SQL injection.
- **Output escaping** with `e()` (`htmlspecialchars`) on all user-supplied text: protects against XSS.
- **CSRF tokens** on both forms.
- **Server-side validation** (the HTML attributes are only a convenience).
- **Credentials kept out of Git**: `config.php` is in `.gitignore`.
- **Generic error messages** to visitors; real database errors go to the server log.
- **Post/Redirect/Get** so refreshing the confirmation page cannot place a duplicate order.
- Orders can only be looked up with the reference code **and** the matching email.

## Unique features
- Live inventory: ordering reduces stock, and the catalog shows "Only N left" / "Out of stock" badges.
- Race-safe ordering using a transaction and `SELECT ... FOR UPDATE`.
- Price snapshot saved with each order, so later price changes don't alter past orders.
- Random reference codes (`BOB-XXXXXXXX`) and a private order tracker.
- Delivery address box appears only when delivery is chosen.
- Navigation highlights the current page automatically, and new pages are added by editing one array in `header.php`.

## Limitations
There is no admin login. To change an order's status (`received`, `ready`, `completed`, `cancelled`) edit the row in phpMyAdmin.
