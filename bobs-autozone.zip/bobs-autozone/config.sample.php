<?php
/**
 * config.sample.php
 * -------------------------------------------------------------
 * Copy this file to config.php and fill in YOUR database details.
 * config.php is listed in .gitignore so your password is never
 * uploaded to GitHub.
 * -------------------------------------------------------------
 */
return [
    'db_host'    => 'localhost',     // XAMPP default; a web host may give you another name
    'db_name'    => 'bobs_autozone', // database created by database/schema.sql
    'db_user'    => 'root',          // XAMPP default; use the DB user from your host
    'db_pass'    => '',              // XAMPP default is empty; use a strong password online
    'db_charset' => 'utf8mb4',
];
