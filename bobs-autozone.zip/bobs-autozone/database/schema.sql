-- ===============================================================
-- Bob's Autozone - database schema + sample data
-- Import in phpMyAdmin (Import tab) or run:  mysql -u root -p < database/schema.sql
-- ===============================================================

CREATE DATABASE IF NOT EXISTS bobs_autozone
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bobs_autozone;

-- Parts catalog (read by the home page, parts page and order form)
CREATE TABLE IF NOT EXISTS parts (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sku         VARCHAR(20)   NOT NULL UNIQUE,
    name        VARCHAR(120)  NOT NULL,
    category    VARCHAR(40)   NOT NULL,
    description VARCHAR(255)  NOT NULL,
    price       DECIMAL(8,2)  NOT NULL,
    stock       INT UNSIGNED  NOT NULL DEFAULT 0,
    created_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Every submission of the order form is saved here
CREATE TABLE IF NOT EXISTS part_requests (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ref_code       VARCHAR(16)   NOT NULL UNIQUE,      -- e.g. BOB-3FA91C2E
    customer_name  VARCHAR(80)   NOT NULL,
    email          VARCHAR(120)  NOT NULL,
    phone          VARCHAR(25)   NULL,
    vehicle_year   SMALLINT UNSIGNED NOT NULL,
    vehicle_make   VARCHAR(40)   NOT NULL,
    vehicle_model  VARCHAR(40)   NOT NULL,
    part_id        INT UNSIGNED  NOT NULL,
    quantity       TINYINT UNSIGNED NOT NULL,
    unit_price     DECIMAL(8,2)  NOT NULL,             -- price at time of order
    total_price    DECIMAL(9,2)  NOT NULL,
    fulfillment    ENUM('pickup','delivery') NOT NULL,
    address        VARCHAR(200)  NULL,                 -- only for delivery
    notes          TEXT          NULL,
    status         ENUM('received','ready','completed','cancelled') NOT NULL DEFAULT 'received',
    created_at     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_request_part FOREIGN KEY (part_id) REFERENCES parts(id)
) ENGINE=InnoDB;

INSERT INTO parts (sku, name, category, description, price, stock) VALUES
('OIL-5W30-5Q', '5W-30 Synthetic Motor Oil, 5 qt',   'Fluids',     'Full synthetic oil for most modern gas engines.',        28.99, 40),
('FLT-OIL-114', 'Spin-On Oil Filter',                'Filters',    'Fits many Toyota, Honda and Nissan models.',              7.49, 60),
('FLT-AIR-220', 'Engine Air Filter',                 'Filters',    'High-flow paper element, easy drop-in install.',         14.99, 35),
('BRK-PAD-CER', 'Ceramic Brake Pads (front set)',    'Brakes',     'Quiet, low-dust pads with hardware kit.',                44.95, 22),
('BRK-ROT-300', 'Vented Brake Rotor',                'Brakes',     'Coated rotor, sold individually.',                       39.50, 18),
('BAT-GRP-35',  'Group 35 Car Battery',              'Electrical', '640 CCA, 3-year warranty. Core charge may apply.',      119.99, 12),
('SPK-IRID-4',  'Iridium Spark Plugs (4 pack)',      'Ignition',   'Long-life plugs, pre-gapped.',                           31.96, 28),
('WPR-BLD-22',  '22" Wiper Blade',                   'Wipers',     'All-season beam blade.',                                 12.99, 50),
('BLB-H11-2',   'H11 LED Headlight Bulbs (pair)',    'Lighting',   'Plug-and-play LED upgrade, 6000K white.',                38.00, 25),
('CLN-COOL-1G', '50/50 Antifreeze Coolant, 1 gal',   'Fluids',     'Ready-to-use, all makes and models.',                    16.49, 45),
('BLT-SERP-6',  'Serpentine Belt',                   'Belts',      'EPDM belt, check size against your vehicle.',            24.99, 15),
('JMP-CBL-12',  'Heavy-Duty Jumper Cables, 12 ft',   'Accessories','4-gauge copper clad cables with carry bag.',             29.99, 20);
