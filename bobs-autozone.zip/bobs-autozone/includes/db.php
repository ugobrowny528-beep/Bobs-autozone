<?php
/**
 * includes/db.php
 * -------------------------------------------------------------
 * Creates ONE secure database connection using PDO (PHP Data
 * Objects) and shares it with every page via db().
 *
 * Security notes:
 *  - Credentials live in config.php (not committed to GitHub).
 *  - PDO exceptions are turned on so errors are never silent.
 *  - Real prepared statements are used (emulation OFF) to prevent
 *    SQL injection.
 *  - If the connection fails, visitors see a generic message; the
 *    real error goes to the server log, never to the browser.
 * -------------------------------------------------------------
 */

function db(): PDO
{
    static $pdo = null;          // remember the connection between calls
    if ($pdo !== null) {
        return $pdo;
    }

    $configFile = __DIR__ . '/../config.php';
    if (!file_exists($configFile)) {
        http_response_code(500);
        exit('Setup needed: copy config.sample.php to config.php and enter your database details.');
    }
    $cfg = require $configFile;

    $dsn = "mysql:host={$cfg['db_host']};dbname={$cfg['db_name']};charset={$cfg['db_charset']}";

    try {
        $pdo = new PDO($dsn, $cfg['db_user'], $cfg['db_pass'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,   // throw on errors
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,         // rows as arrays
            PDO::ATTR_EMULATE_PREPARES   => false,                    // real prepared statements
        ]);
    } catch (PDOException $e) {
        error_log('DB connection failed: ' . $e->getMessage());       // log details privately
        http_response_code(500);
        exit('Sorry, Bob\'s shop is having database trouble. Please try again soon.');
    }

    return $pdo;
}
