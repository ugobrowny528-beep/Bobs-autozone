<?php
/**
 * includes/footer.php
 * Shared footer: closes <main>, shows shop details and copyright,
 * and closes the HTML document opened by header.php.
 */
?>
</main>

<footer class="site-footer">
    <div class="footer-grid">
        <div>
            <h2>Shop hours</h2>
            <p>Mon &ndash; Sat: 7 am &ndash; 8 pm<br>Sun: 9 am &ndash; 5 pm</p>
        </div>
        <div>
            <h2>Visit Bob</h2>
            <p>1450 Route 9 Service Road<br>Albany, NY 12205</p>
        </div>
        <div>
            <h2>Talk to us</h2>
            <p><a href="tel:+15185550199">(518) 555-0199</a><br>
               <a href="mailto:parts@bobsautozone.example">parts@bobsautozone.example</a></p>
        </div>
    </div>
    <p class="copyright">&copy; <?php echo date('Y'); ?> Bob's Autozone. Student project, not a real store.</p>
</footer>
</body>
</html>
