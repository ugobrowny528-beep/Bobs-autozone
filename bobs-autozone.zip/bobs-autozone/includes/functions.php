<?php
/**
 * includes/functions.php
 * -------------------------------------------------------------
 * Small helpers shared by all pages:
 *   e()            - escape text before printing it in HTML
 *   csrf_*()       - protect forms from cross-site request forgery
 *   save_request() - validates stock and saves an order to the DB
 *   find_request() - looks an order up by reference code + email
 * -------------------------------------------------------------
 */

session_start();   // sessions hold the CSRF token and the last order reference

/** Escape output so user text can never inject HTML/JavaScript (XSS). */
function e(?string $text): string
{
    return htmlspecialchars((string) $text, ENT_QUOTES, 'UTF-8');
}

/** Create (once per session) and return a random CSRF token. */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

/** Print the hidden form field that carries the token. */
function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

/** True only if the submitted token matches the one in the session. */
function csrf_valid(): bool
{
    return isset($_POST['csrf'], $_SESSION['csrf'])
        && hash_equals($_SESSION['csrf'], $_POST['csrf']);
}

/**
 * Save one order into part_requests.
 *
 * Runs inside a TRANSACTION so the stock check, the INSERT and the
 * stock reduction either all succeed or none do.
 * Returns the new reference code. Throws RuntimeException with a
 * friendly message if the part is gone or stock is too low.
 */
function save_request(PDO $pdo, array $d): string
{
    $pdo->beginTransaction();
    try {
        // Lock the part row so two shoppers can't buy the last item at once.
        $stmt = $pdo->prepare('SELECT price, stock FROM parts WHERE id = :id FOR UPDATE');
        $stmt->execute([':id' => $d['part_id']]);
        $part = $stmt->fetch();

        if (!$part) {
            throw new RuntimeException('That part is no longer in our catalog.');
        }
        if ((int) $part['stock'] < $d['quantity']) {
            throw new RuntimeException('Sorry, only ' . (int) $part['stock'] . ' of that part left in stock.');
        }

        $unit  = (float) $part['price'];            // price comes from the DB, never the browser
        $total = $unit * $d['quantity'];
        $ref   = 'BOB-' . strtoupper(bin2hex(random_bytes(4)));

        $insert = $pdo->prepare(
            'INSERT INTO part_requests
                (ref_code, customer_name, email, phone, vehicle_year, vehicle_make,
                 vehicle_model, part_id, quantity, unit_price, total_price,
                 fulfillment, address, notes)
             VALUES
                (:ref, :name, :email, :phone, :year, :make,
                 :model, :part, :qty, :unit, :total,
                 :fulfil, :address, :notes)'
        );
        $insert->execute([
            ':ref'     => $ref,
            ':name'    => $d['customer_name'],
            ':email'   => $d['email'],
            ':phone'   => $d['phone'] !== '' ? $d['phone'] : null,
            ':year'    => $d['vehicle_year'],
            ':make'    => $d['vehicle_make'],
            ':model'   => $d['vehicle_model'],
            ':part'    => $d['part_id'],
            ':qty'     => $d['quantity'],
            ':unit'    => $unit,
            ':total'   => $total,
            ':fulfil'  => $d['fulfillment'],
            ':address' => $d['address'] !== '' ? $d['address'] : null,
            ':notes'   => $d['notes'] !== '' ? $d['notes'] : null,
        ]);

        // Take the purchased units out of stock.
        $update = $pdo->prepare('UPDATE parts SET stock = stock - :qty WHERE id = :id');
        $update->execute([':qty' => $d['quantity'], ':id' => $d['part_id']]);

        $pdo->commit();
        return $ref;
    } catch (Throwable $e) {
        $pdo->rollBack();    // undo everything if anything failed
        throw $e;
    }
}

/** Find an order by reference code AND email (so strangers can't peek). */
function find_request(PDO $pdo, string $ref, string $email): ?array
{
    $stmt = $pdo->prepare(
        'SELECT r.*, p.name AS part_name, p.sku
           FROM part_requests r
           JOIN parts p ON p.id = r.part_id
          WHERE r.ref_code = :ref AND r.email = :email'
    );
    $stmt->execute([':ref' => strtoupper($ref), ':email' => $email]);
    $row = $stmt->fetch();
    return $row ?: null;
}
