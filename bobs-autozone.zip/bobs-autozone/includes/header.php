<?php
/**
 * includes/header.php
 * Shared header: opens the HTML page, loads CSS, prints the logo and
 * navigation. Pages set $pageTitle before including this file.
 */
$pageTitle   = $pageTitle ?? 'Welcome';
$currentPage = basename($_SERVER['PHP_SELF']);

// file => label. Add a page here and it appears in every page's nav.
$navLinks = [
    'index.php'  => 'Home',
    'parts.php'  => 'Parts',
    'order.php'  => 'Order a Part',
    'status.php' => 'Track Order',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($pageTitle); ?> | Bob's Autozone</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;800&family=Barlow:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>

<header class="site-header">
    <a class="brand" href="index.php">
        <span class="brand-badge" aria-hidden="true">B</span>
        <span class="brand-name">Bob's <em>Autozone</em></span>
    </a>
    <nav aria-label="Main navigation">
        <ul class="nav">
            <?php foreach ($navLinks as $file => $label): ?>
                <li><a href="<?php echo $file; ?>"
                       <?php if ($file === $currentPage) echo 'class="active" aria-current="page"'; ?>><?php echo $label; ?></a></li>
            <?php endforeach; ?>
        </ul>
    </nav>
</header>
<div class="hazard-strip" aria-hidden="true"></div>

<main id="main">
