<?php
/**
 * index.php - Home page
 * Pulls live data from the database: three random parts and a count of
 * how many parts are in stock.
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/db.php';

$pageTitle = 'Home';
$pdo = db();

$featured   = $pdo->query('SELECT * FROM parts WHERE stock > 0 ORDER BY RAND() LIMIT 3')->fetchAll();
$totalParts = (int) $pdo->query('SELECT COUNT(*) FROM parts WHERE stock > 0')->fetchColumn();

include 'includes/header.php';
?>

<section class="hero">
    <p class="eyebrow">Parts counter open now</p>
    <h1>Fix it yourself.<br>Bob's got the parts.</h1>
    <p class="lead"><?php echo $totalParts; ?> parts in stock, from oil filters to batteries. Tell us your car, pick a part, and we'll have it ready.</p>
    <a class="button" href="order.php">Order a part</a>
    <a class="button button-ghost" href="parts.php">Browse the catalog</a>
</section>

<section>
    <h2>Pulled from the shelf today</h2>
    <div class="card-grid">
        <?php foreach ($featured as $part): ?>
            <article class="card">
                <span class="tag"><?php echo e($part['category']); ?></span>
                <h3><?php echo e($part['name']); ?></h3>
                <p><?php echo e($part['description']); ?></p>
                <p class="price">$<?php echo number_format((float) $part['price'], 2); ?></p>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
