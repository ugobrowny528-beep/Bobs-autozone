<?php
/**
 * order.php - Part order form (THE FORM THAT SAVES TO THE DATABASE)
 *
 * Flow:
 *  1. Visitor sees the form (part list comes from the DB).
 *  2. On submit we check the CSRF token, clean + validate every field.
 *  3. If valid, save_request() stores the order in `part_requests`
 *     with a prepared statement inside a transaction.
 *  4. We redirect to status.php (Post/Redirect/Get) so refreshing the
 *     page can never submit the order twice.
 *
 * NOTE: all logic runs BEFORE header.php is included, because
 * header() redirects must happen before any HTML is output.
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/db.php';

$pageTitle = 'Order a Part';
$pdo = db();

// Parts that can be ordered (in stock only)
$parts = $pdo->query('SELECT id, name, sku, price, stock FROM parts WHERE stock > 0 ORDER BY name')->fetchAll();
$partIds = array_column($parts, 'id');

$errors = [];
$old = [   // values we re-fill into the form if there is an error
    'customer_name' => '', 'email' => '', 'phone' => '',
    'vehicle_year'  => '', 'vehicle_make' => '', 'vehicle_model' => '',
    'part_id' => $_GET['part'] ?? '', 'quantity' => '1',
    'fulfillment' => 'pickup', 'address' => '', 'notes' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!csrf_valid()) {
        $errors[] = 'Your session expired. Please try again.';
    }

    // 1. Collect + trim every field (missing fields become '')
    foreach ($old as $field => $default) {
        $old[$field] = trim($_POST[$field] ?? '');
    }

    // 2. Validate
    if ($old['customer_name'] === '' || mb_strlen($old['customer_name']) > 80) {
        $errors[] = 'Enter your name (80 characters max).';
    }
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($old['email']) > 120) {
        $errors[] = 'Enter a valid email address.';
    }
    if ($old['phone'] !== '' && !preg_match('/^[0-9+()\-\s.]{7,25}$/', $old['phone'])) {
        $errors[] = 'Phone numbers can only contain digits, spaces, + ( ) - .';
    }
    $maxYear = (int) date('Y') + 1;
    if (!ctype_digit($old['vehicle_year']) || $old['vehicle_year'] < 1960 || $old['vehicle_year'] > $maxYear) {
        $errors[] = "Vehicle year must be between 1960 and $maxYear.";
    }
    if ($old['vehicle_make'] === '' || mb_strlen($old['vehicle_make']) > 40) {
        $errors[] = 'Enter your vehicle make (for example, Toyota).';
    }
    if ($old['vehicle_model'] === '' || mb_strlen($old['vehicle_model']) > 40) {
        $errors[] = 'Enter your vehicle model (for example, Camry).';
    }
    if (!ctype_digit($old['part_id']) || !in_array((int) $old['part_id'], array_map('intval', $partIds), true)) {
        $errors[] = 'Choose a part from the list.';
    }
    if (!ctype_digit($old['quantity']) || $old['quantity'] < 1 || $old['quantity'] > 10) {
        $errors[] = 'Quantity must be between 1 and 10.';
    }
    if (!in_array($old['fulfillment'], ['pickup', 'delivery'], true)) {
        $errors[] = 'Choose pickup or delivery.';
    }
    if ($old['fulfillment'] === 'delivery' && $old['address'] === '') {
        $errors[] = 'Enter a delivery address.';
    }
    if (mb_strlen($old['address']) > 200) {
        $errors[] = 'Address is too long (200 characters max).';
    }
    if (mb_strlen($old['notes']) > 1000) {
        $errors[] = 'Notes are too long (1000 characters max).';
    }

    // 3. Save to the database if everything is valid
    if (empty($errors)) {
        try {
            $ref = save_request($pdo, [
                'customer_name' => $old['customer_name'],
                'email'         => $old['email'],
                'phone'         => $old['phone'],
                'vehicle_year'  => (int) $old['vehicle_year'],
                'vehicle_make'  => $old['vehicle_make'],
                'vehicle_model' => $old['vehicle_model'],
                'part_id'       => (int) $old['part_id'],
                'quantity'      => (int) $old['quantity'],
                'fulfillment'   => $old['fulfillment'],
                'address'       => $old['fulfillment'] === 'delivery' ? $old['address'] : '',
                'notes'         => $old['notes'],
            ]);

            // Remember this order so status.php can show it without retyping the email
            $_SESSION['last_ref']   = $ref;
            $_SESSION['last_email'] = $old['email'];
            header('Location: status.php?ref=' . urlencode($ref) . '&placed=1');
            exit;

        } catch (RuntimeException $ex) {
            $errors[] = $ex->getMessage();                 // friendly: out of stock, etc.
        } catch (PDOException $ex) {
            error_log('Order save failed: ' . $ex->getMessage());
            $errors[] = 'We could not save your order. Please try again.';
        }
    }
}

include 'includes/header.php';
?>

<section class="page-intro">
    <h1>Order a part</h1>
    <p class="lead">Fill this out and we'll set the part aside. You'll get a reference code to track it.</p>
</section>

<?php if (!empty($errors)): ?>
    <div class="notice error" role="alert">
        <p><strong>Fix these and send again:</strong></p>
        <ul><?php foreach ($errors as $error): ?><li><?php echo e($error); ?></li><?php endforeach; ?></ul>
    </div>
<?php endif; ?>

<form class="form" method="post" action="order.php" novalidate>
    <?php echo csrf_field(); ?>

    <fieldset>
        <legend>About you</legend>
        <label for="customer_name">Full name</label>
        <input type="text" id="customer_name" name="customer_name" maxlength="80" value="<?php echo e($old['customer_name']); ?>" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" maxlength="120" value="<?php echo e($old['email']); ?>" required>

        <label for="phone">Phone <span class="small">(optional)</span></label>
        <input type="tel" id="phone" name="phone" maxlength="25" value="<?php echo e($old['phone']); ?>">
    </fieldset>

    <fieldset>
        <legend>Your vehicle</legend>
        <div class="row">
            <div>
                <label for="vehicle_year">Year</label>
                <input type="number" id="vehicle_year" name="vehicle_year" min="1960" max="<?php echo (int) date('Y') + 1; ?>" value="<?php echo e($old['vehicle_year']); ?>" required>
            </div>
            <div>
                <label for="vehicle_make">Make</label>
                <input type="text" id="vehicle_make" name="vehicle_make" maxlength="40" placeholder="Toyota" value="<?php echo e($old['vehicle_make']); ?>" required>
            </div>
            <div>
                <label for="vehicle_model">Model</label>
                <input type="text" id="vehicle_model" name="vehicle_model" maxlength="40" placeholder="Camry" value="<?php echo e($old['vehicle_model']); ?>" required>
            </div>
        </div>
    </fieldset>

    <fieldset>
        <legend>The part</legend>
        <label for="part_id">Part</label>
        <select id="part_id" name="part_id" required>
            <option value="">Choose a part...</option>
            <?php foreach ($parts as $part): ?>
                <option value="<?php echo (int) $part['id']; ?>"
                    <?php if ((string) $part['id'] === $old['part_id']) echo 'selected'; ?>>
                    <?php echo e($part['name']); ?> - $<?php echo number_format((float) $part['price'], 2); ?>
                    (<?php echo (int) $part['stock']; ?> in stock)
                </option>
            <?php endforeach; ?>
        </select>

        <label for="quantity">Quantity</label>
        <input type="number" id="quantity" name="quantity" min="1" max="10" value="<?php echo e($old['quantity']); ?>" required>
    </fieldset>

    <fieldset>
        <legend>Getting it</legend>
        <label class="choice"><input type="radio" name="fulfillment" value="pickup" <?php if ($old['fulfillment'] === 'pickup') echo 'checked'; ?>> Pick up at the shop</label>
        <label class="choice"><input type="radio" name="fulfillment" value="delivery" <?php if ($old['fulfillment'] === 'delivery') echo 'checked'; ?>> Deliver to me</label>

        <div id="address-box">
            <label for="address">Delivery address</label>
            <input type="text" id="address" name="address" maxlength="200" value="<?php echo e($old['address']); ?>">
        </div>

        <label for="notes">Notes <span class="small">(trim level, engine size, anything else)</span></label>
        <textarea id="notes" name="notes" rows="4" maxlength="1000"><?php echo e($old['notes']); ?></textarea>
    </fieldset>

    <button class="button" type="submit">Place order</button>
</form>

<script>
// Small convenience: only show the address box when "Deliver to me" is chosen.
// The server still validates the address, so this is cosmetic.
(function () {
    var box = document.getElementById('address-box');
    var radios = document.querySelectorAll('input[name="fulfillment"]');
    function update() {
        var delivery = document.querySelector('input[name="fulfillment"]:checked').value === 'delivery';
        box.style.display = delivery ? 'block' : 'none';
    }
    radios.forEach(function (r) { r.addEventListener('change', update); });
    update();
})();
</script>

<?php include 'includes/footer.php'; ?>
