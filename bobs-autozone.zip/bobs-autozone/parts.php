<?php
/**
 * parts.php - Parts catalog
 * Reads parts from the database. Optional ?category= filter uses a
 * prepared statement, so the value can't be used for SQL injection.
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/db.php';

$pageTitle = 'Parts';
$pdo = db();

// Category list for the filter buttons
$categories = $pdo->query('SELECT DISTINCT category FROM parts ORDER BY category')->fetchAll(PDO::FETCH_COLUMN);

$selected = $_GET['category'] ?? '';
if ($selected !== '' && in_array($selected, $categories, true)) {
    $stmt = $pdo->prepare('SELECT * FROM parts WHERE category = :cat ORDER BY name');
    $stmt->execute([':cat' => $selected]);
} else {
    $selected = '';
    $stmt = $pdo->query('SELECT * FROM parts ORDER BY category, name');
}
$parts = $stmt->fetchAll();

include 'includes/header.php';
?>

<section class="page-intro">
    <h1>Parts catalog</h1>
    <p class="lead">Live inventory. Stock counts update as orders come in.</p>
</section>

<nav class="filters" aria-label="Filter by category">
    <a href="parts.php" <?php if ($selected === '') echo 'class="active"'; ?>>All</a>
    <?php foreach ($categories as $cat): ?>
        <a href="parts.php?category=<?php echo urlencode($cat); ?>"
           <?php if ($selected === $cat) echo 'class="active"'; ?>><?php echo e($cat); ?></a>
    <?php endforeach; ?>
</nav>

<div class="table-wrap">
<table class="parts-table">
    <thead>
        <tr><th>Part</th><th>Category</th><th>SKU</th><th>Stock</th><th>Price</th></tr>
    </thead>
    <tbody>
    <?php foreach ($parts as $part): ?>
        <tr>
            <td><strong><?php echo e($part['name']); ?></strong><br>
                <span class="small"><?php echo e($part['description']); ?></span></td>
            <td><?php echo e($part['category']); ?></td>
            <td><code><?php echo e($part['sku']); ?></code></td>
            <td>
                <?php if ($part['stock'] == 0): ?>
                    <span class="badge out">Out of stock</span>
                <?php elseif ($part['stock'] <= 15): ?>
                    <span class="badge low">Only <?php echo (int) $part['stock']; ?> left</span>
                <?php else: ?>
                    <span class="badge ok">In stock</span>
                <?php endif; ?>
            </td>
            <td class="price">$<?php echo number_format((float) $part['price'], 2); ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</div>

<?php include 'includes/footer.php'; ?>
