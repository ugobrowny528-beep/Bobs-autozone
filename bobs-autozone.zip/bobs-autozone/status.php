<?php
/**
 * status.php - Order confirmation + order tracker
 * Reads an order back out of the database. A visitor must supply the
 * reference code AND the email used on the order, so orders stay private.
 * Right after ordering, the code/email come from the session instead.
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/db.php';

$pageTitle = 'Track Order';
$pdo = db();

$order  = null;
$error  = '';
$placed = isset($_GET['placed']);
$ref    = trim($_GET['ref'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Manual lookup form
    if (!csrf_valid()) {
        $error = 'Your session expired. Please try again.';
    } else {
        $ref   = trim($_POST['ref'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $order = find_request($pdo, $ref, $email);
        if (!$order) {
            $error = 'No order found with that reference code and email.';
        }
    }
} elseif ($ref !== '' && ($_SESSION['last_ref'] ?? '') === $ref) {
    // Visitor just placed this order in this browser session
    $order = find_request($pdo, $ref, $_SESSION['last_email'] ?? '');
}

include 'includes/header.php';
?>

<?php if ($order): ?>
    <section class="page-intro">
        <?php if ($placed): ?>
            <p class="eyebrow">Order received</p>
            <h1>Thanks, <?php echo e(explode(' ', $order['customer_name'])[0]); ?>!</h1>
            <p class="lead">Save your reference code: <strong><?php echo e($order['ref_code']); ?></strong></p>
        <?php else: ?>
            <h1>Order <?php echo e($order['ref_code']); ?></h1>
        <?php endif; ?>
    </section>

    <div class="receipt">
        <p><span class="badge <?php echo e($order['status']); ?>"><?php echo e(ucfirst($order['status'])); ?></span>
           <span class="small">placed <?php echo e(date('M j, Y g:i a', strtotime($order['created_at']))); ?></span></p>
        <dl>
            <dt>Part</dt><dd><?php echo e($order['part_name']); ?> (<code><?php echo e($order['sku']); ?></code>)</dd>
            <dt>Quantity</dt><dd><?php echo (int) $order['quantity']; ?> &times; $<?php echo number_format((float) $order['unit_price'], 2); ?></dd>
            <dt>Total</dt><dd class="price">$<?php echo number_format((float) $order['total_price'], 2); ?></dd>
            <dt>Vehicle</dt><dd><?php echo (int) $order['vehicle_year'] . ' ' . e($order['vehicle_make']) . ' ' . e($order['vehicle_model']); ?></dd>
            <dt>Getting it</dt>
            <dd><?php echo $order['fulfillment'] === 'pickup' ? 'Pick up at the shop' : 'Delivery to ' . e($order['address']); ?></dd>
            <?php if ($order['notes']): ?><dt>Notes</dt><dd><?php echo nl2br(e($order['notes'])); ?></dd><?php endif; ?>
        </dl>
    </div>
<?php else: ?>
    <section class="page-intro">
        <h1>Track your order</h1>
        <p class="lead">Enter the reference code from your confirmation and the email you used.</p>
    </section>

    <?php if ($error): ?>
        <div class="notice error" role="alert"><p><?php echo e($error); ?></p></div>
    <?php endif; ?>

    <form class="form" method="post" action="status.php">
        <?php echo csrf_field(); ?>
        <label for="ref">Reference code</label>
        <input type="text" id="ref" name="ref" placeholder="BOB-1A2B3C4D" value="<?php echo e($ref); ?>" required>
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>
        <button class="button" type="submit">Look up order</button>
    </form>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
